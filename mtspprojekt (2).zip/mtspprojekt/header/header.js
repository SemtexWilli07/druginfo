function showDropdown() {
    document.querySelector('.dropdown-content').style.display = 'block';
}

function hideDropdown() {
    document.querySelector('.dropdown-content').style.display = 'none';
}

function myFunction(x) {
    x.classList.toggle("change");
}